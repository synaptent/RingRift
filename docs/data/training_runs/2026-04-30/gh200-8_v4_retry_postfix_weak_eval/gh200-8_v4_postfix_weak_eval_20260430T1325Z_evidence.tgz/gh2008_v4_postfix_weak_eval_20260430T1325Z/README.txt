captured_utc=2026-04-30T13:24:04Z
node=gh200-8
workdir=data/minimal_loop_hex8_3p_v4_retry_gh2008_20260430_3a482e0bd
